from instruction.field.y_npc.functions import Y_NPC
