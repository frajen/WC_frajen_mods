id_swdtech = {
    85  : "Dispatch",
    86  : "Retort",
    87  : "Slash",
    88  : "Quadra Slam",
    89  : "Empowerer",
    90  : "Stunner",
    91  : "Quadra Slice",
    92  : "Cleave",
}
swdtech_id = {v: k for k, v in id_swdtech.items()}
