id_blitz = {
    93  : "Pummel",
    94  : "AuraBolt",
    95  : "Suplex",
    96  : "Fire Dance",
    97  : "Mantra",
    98  : "Air Blade",
    99  : "Spiraler",
    100 : "Bum Rush",
}
blitz_id = {v: k for k, v in id_blitz.items()}
